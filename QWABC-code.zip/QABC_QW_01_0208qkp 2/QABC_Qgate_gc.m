function new_bee_population=QABC_Qgate_gc(bee_population,poplulation_bin,cost,best_bin,best_fit,numP,min_thea,max_thea,min_fit)  
%% 量子旋转门调整策略
% 输入  chrom：更新前的量子比特编码
%     fitness：适应度值
%        best：当前种群中最优个体
%      binary：二进制编码
% 输出  chrom：更新后的量子比特编码
%其中r=size(A,1)该语句返回的时矩阵A的行数， c=size(A,2) 该语句返回的时矩阵A的列数。
% clc
% clear
% best_bin=[1 1 1 1 1 1 1 1 1];
% poplulation_quan=[0.707106781186548,0.707106781186548,0.707106781186548,0.707106781186548,0.707106781186548,0.707106781186548,0.707106781186548,0.707106781186548,0.707106781186548;0.707106781186548,0.707106781186548,0.707106781186548,0.707106781186548,0.707106781186548,0.707106781186548,0.707106781186548,0.707106781186548,0.707106781186548];
% poplulation_bin=[1,1,0,1,1,1,0,0,0];
% costi=17.4013;
% best_fit=2;
% s=0;
%k=1.3; %k的取值在1.3~2之间最好
best_fit=best_fit/numP;
cost=cost/numP;
%sizepop=size(poplulation_bin);%返回行数
lenchrom=length(bee_population);%返回矩阵binary矩阵的列数
%for i=1:sizepop
    for j=1:lenchrom
        A=bee_population(1,j);   % α
        B=bee_population(2,j);     % β
        x=poplulation_bin(j); %二进制编码
        b=best_bin(j);%将初始化的二进制编码存入b
        if ((x==0)&&(b==0))||((x==1)&&(b==1))
            delta=0;                  % delta为旋转角的大小
            s=0;                        % s为旋转角的符号，即旋转方向
        elseif all([x==0, b==1, cost<best_fit])
            delta=0;                 
            s=0;
            %delta=min_thea+((best_fit-cost)/best_fit)*(max_thea+min_thea); 
            %if A*B>0
            %    s=1;
            %elseif A*B<0
            %    s=-1;
            %elseif A==0
            %    s=0;
            %elseif B==0
            %    s=sign(randn);
            %end
        elseif all([x==0, b==1, cost>=best_fit])
            delta=min_thea+((best_fit-cost)/best_fit)*(max_thea+min_thea);
            %delta=0.2*(max_thea-min_thea)+(abs(cost/(best_fit-min_fit)))*(max_thea-min_thea);
            if A*B>0
                s=-1;
            elseif A*B<0
                s=1;
            elseif A==0
                s=sign(randn);
            elseif B==0
                s=0;
            end
        elseif all([x==1, b==0, cost<best_fit])
            delta=0;                 
            s=0;
            %delta=min_thea+((best_fit-cost)/best_fit)*(max_thea+min_thea);
            %if A*B>0
            %    s=-1;
            %elseif A*B<0
            %    s=1;
            %elseif A==0
            %    s=sign(randn);
            %elseif B==0
            %    s=0;
            %end
        elseif all([x==1, b==0, cost>=best_fit])
            delta=min_thea+((best_fit-cost)/best_fit)*(max_thea+min_thea);
            %delta=0.2*(max_thea-min_thea)+(abs(cost/(best_fit-min_fit)))*(max_thea-min_thea);
            if A*B>0
                s=1;
            elseif A*B<0
                s=-1;
            elseif A==0
                s=0;
            elseif B==0
                s=sign(randn);
            end
        end
        e=s*delta;       % e为旋转角  
        U=[cos(e) -sin(e);sin(e) cos(e)];      % 量子旋转门
        y=U*[A B]';        % y为更新后的量子位
        new_bee_population(1,j)=y(1);
        new_bee_population(2,j)=y(2);
        U=0;
    end
   %在更新过程中，旋转角起到关键的作用，当角度过小会影响收敛速度，过大会导致早熟
   %当比特位位于第一三象限时，
    
end
