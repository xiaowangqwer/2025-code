% 示例输入
bitStream = [1,0,1,1,0,1,0,0,1,1,0,1,1,0,1,1,1,0,1,0,0,1,0,1,1,0,0,1,1]; % 1×29 的二进制数组
a = [2,1,1,1,1,1,1,1,2,2,2,2,2,3,2,1,1,3]; % 维度矩阵

% 检查二进制串长度与维度矩阵总和是否匹配
if sum(a) ~= numel(bitStream)
    error('二进制串长度与维度矩阵的总和不匹配');
end

% 初始化结果矩阵
decimalResult = zeros(1, numel(a));
startIdx = 1; % 起始索引

% 逐段解析二进制串
for i = 1:numel(a)
    nBits = a(i); % 当前段需要的二进制位数
    endIdx = startIdx + nBits - 1; % 结束索引
    currentBits = bitStream(startIdx:endIdx); % 提取当前段的二进制位
    
    % 将二进制转换为十进制（高位在前）
    decimalValue = sum(currentBits .* 2.^(nBits-1:-1:0));
    decimalResult(i) = decimalValue;
    
    startIdx = endIdx + 1; % 更新起始索引
end

% 输出结果
disp(decimalResult);