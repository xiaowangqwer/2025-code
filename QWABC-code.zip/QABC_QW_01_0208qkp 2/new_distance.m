function d = new_distance(x, z, data,m)
    % 计算样本 x 和聚类中心 z 的新距离
    % 输入:
    %   x - 一个样本向量
    %   z - 一个聚类中心向量
    %   data - 整个数据集，用于计算外部距离
    % 输出:
    %   d - 计算出的距离值
    
    %[n, m] = size(data);  % 获取样本数和特征数
    d = 0;  
    for i = 1:m
        % 计算内部距离（简单的0-1匹配）
        if x(i) == z(i)
            internal_dist = 0;  % 如果当前特征值相同，内部距离为 0
        else
            internal_dist = 1;  % 如果当前特征值不同，内部距离为 1
        end
        
        % 计算外部距离
external_dist = 0;  % 初始化外部距离
U_size = size(data, 1);  % 数据集 U 的大小
X = find(data(:, i) == x(i));  % 属性 ai 的值为 x(i) 的对象索引集合
Y = find(data(:, i) == z(i));  % 属性 ai 的值为 z(i) 的对象索引集合

for j = 1:m
    if j ~= i  % 排除当前特征 ai，计算其他特征 aj 的外部距离
        % 初始化分母和分子
        sum_diff = 0;  % |μ(X) - μ(Y)| 的累积和
        for x_idx = 1:U_size          
            % 计算对象 x 在 X 和 Y 上的粗糙隶属度
            x_class = find(data(:, j) == data(x_idx, j));  % x 关于 aj 的等价类
            mu_X = sum(ismember(x_class, X)) / length(x_class);  % μaj^X(x)
            mu_Y = sum(ismember(x_class, Y)) / length(x_class);  % μaj^Y(x)
            sum_diff = sum_diff + abs(mu_X - mu_Y);  % 累加 |μaj^X(x) - μaj^Y(x)|
        end
        external_dist = external_dist + sum_diff / U_size;  % 按照公式计算
    end
end
external_dist = external_dist / m;  % 平均化外部距离

        
        % 综合内部距离和外部距离
        d = d + (internal_dist/ m + external_dist);  % 累加每个特征的距离
    end
end