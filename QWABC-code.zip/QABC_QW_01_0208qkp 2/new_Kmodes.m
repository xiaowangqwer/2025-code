function [cx, centroids] = new_Kmodes(data, k, maxIter)
% data: 数据矩阵，每一行是一个对象，每一列是一个属性
% k: 聚类个数
% maxIter: 最大迭代次数

% 步骤1: 计算每个属性下任意两个属性值之间的距离
numAttributes = size(data, 2); % 获取数据的属性个数
distanceMatrix = zeros(numAttributes); % 初始化距离矩阵，用于存储每个属性下不同属性值之间的距离

for i = 1:numAttributes % 遍历每个属性
    uniqueValues = unique(data(:, i)); % 获取当前属性的所有唯一值
    for j = 1:length(uniqueValues) % 遍历当前属性的唯一值
        for l = j + 1:length(uniqueValues) % 计算两两唯一值之间的距离（避免重复计算，因为距离是对称的）
            p = uniqueValues(j); % 取第一个值
            q = uniqueValues(l); % 取第二个值
            X = find(data(:, i) == p); % 找到数据中当前属性值为p的对象索引
            Y = find(data(:, i) == q); % 找到数据中当前属性值为q的对象索引
            U = 1:size(data, 1); % 定义论域，即所有对象的索引
            mu_X = zeros(size(U)); % 初始化属性值p的粗糙隶属度向量
            mu_Y = zeros(size(U)); % 初始化属性值q的粗糙隶属度向量
            for m = 1:length(U) % 遍历论域中的每个对象
                mu_X(m) = length(intersect(X, find(data(m, :) == data(U(m), :)))) / length(find(data(m, :) == data(U(m), :)));
                % 计算对象m对于属性值p的粗糙隶属度，分子是对象m在其他属性上与属性值为p的对象相同的个数，分母是对象m在其他属性上相同的对象总数
                mu_Y(m) = length(intersect(Y, find(data(m, :) == data(U(m), :)))) / length(find(data(m, :) == data(U(m), :)));
                % 计算对象m对于属性值q的粗糙隶属度
            end
            delta_a_j = sum(abs(mu_X - mu_Y)) / length(U); % 计算属性值p和q相对于当前属性i的外部距离
            distanceMatrix(i, j) = delta_a_j; % 将计算得到的距离存入距离矩阵
            distanceMatrix(i, l) = delta_a_j; % 因为距离对称，同时存入对称位置
        end
    end
end

% 步骤2: 随机选择初始类中心
centroids = zeros(k, numAttributes); % 初始化类中心矩阵
randomIndices = randi(size(data, 1), k, 1); % 随机生成k个对象的索引，作为初始类中心
for i = 1:k
    centroids(i, :) = data(randomIndices(i), :); % 将随机选择的对象作为初始类中心
end

clusterLabels = zeros(size(data, 1), 1); % 初始化对象的聚类标签向量
for iter = 1:maxIter % 开始迭代
    % 步骤3: 分配对象到最近类
    for i = 1:size(data, 1) % 遍历每个对象
        minDistance = Inf; % 初始化最小距离为无穷大
        for j = 1:k % 遍历每个类
            distance = 0; % 初始化当前对象到类j的距离为0
            for l = 1:numAttributes % 遍历每个属性
                p = data(i, l); % 当前对象的属性值
                q = centroids(j, l); % 类j中心的属性值
                if p ~= q % 如果属性值不同
                    distance = distance + distanceMatrix(l, find(unique(data(:, l)) == p, 1));
                    % 根据距离矩阵计算当前属性下的距离并累加到总距离中
                end
            end
            if distance < minDistance % 如果当前距离小于最小距离
                minDistance = distance; % 更新最小距离
                clusterLabels(i) = j; % 将当前对象分配到类j
            end
        end
    end
    
    % 步骤4: 更新类中心（基于频率方法取众数）
    cx=clusterLabels';
    newCentroids = compueCentroids(data,cx,k);
    %{
    newCentroids = cell(k, 1); % 初始化新的类中心单元数组，每个单元存储一个类的中心属性值
    for i = 1:k
        newCentroids{i} = cell(numAttributes, 1); % 为每个类的每个属性初始化单元
    end
    for i = 1:size(data, 1) % 遍历每个对象
        cluster = clusterLabels(i); % 获取当前对象所属的类
        for j = 1:numAttributes % 遍历每个属性
            newCentroids{cluster}{j} = [newCentroids{cluster}{j}; data(i, j)]; % 将当前对象的属性值添加到所属类的相应属性单元中
        end
    end
    for i = 1:k % 遍历每个类
        for j = 1:numAttributes % 遍历每个属性
            values = cell2mat(newCentroids{i}(j)); % 将单元数组中的属性值转换为普通矩阵
            uniqueValues = unique(values); % 获取属性的唯一值
            if length(uniqueValues) == 1 % 如果只有一个唯一值，直接取该值作为类中心属性值
                centroids(i, j) = uniqueValues;
            else % 如果有多个唯一值，计算众数并取众数作为类中心属性值
                [~, modeIndex] = mode(values);
                
                centroids(i, j) = uniqueValues(modeIndex);
            end
        end
    end
    %}
    % 检查是否收敛
    if isequal(centroids, newCentroids) % 如果新类中心和旧类中心相同
        break; % 停止迭代
    end
end
end