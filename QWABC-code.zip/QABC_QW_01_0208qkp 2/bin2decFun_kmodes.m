function X_data=bin2decFun_kmodes(x,k,weidu_juzhen,bianma_length)
%% 二进制转化成十进制
% 输入      x：二进制编码 
%    lenchrom：各变量的二进制位数
%       bound：各变量的范围
% 输出      X：十进制数
% clc
% clear all
% x=[0 0 0 1 1 1 0 1 0];
% bound=[-10 10];
% D=3;
% Dim=3;
global D Dim

M=D;%长度 M=3
X_data=0;
Xtemp=0; %生成1*3全0矩阵
for t=1:k
    u=bianma_length*t-(bianma_length-1);
    X=x(u:u+(bianma_length-1));
    startIdx = 1; % 起始索引
%
for i=1:Dim
    nBits = weidu_juzhen(i); % 当前段需要的二进制位数
    endIdx = startIdx + nBits - 1; % 结束索引
    currentBits = X(startIdx:endIdx); % 提取当前段的二进制位
    
    % 将二进制转换为十进制（高位在前）
    Xtemp = sum(currentBits .* 2.^(nBits-1:-1:0));
    X_data=[X_data Xtemp];
    startIdx = endIdx + 1; % 更新起始索引
    Xtemp=0;
end
%}
%{
for i=1:Dim %循环条件
    p=weidu_juzhen(1,i)-1;
    D_p=weidu_juzhen(1,i);
    %for j=1:D_p
    for j=0:D_p-1   
        Xtemp=Xtemp+X((i-1)+D_p+j+1)*2^p;  %x(n)
        %Xtemp=Xtemp+X((i-1)*D_p+j+1)*2^p;  %x(n)
        p=p-1;
    end
    X_data=[X_data Xtemp];
    %X(i)=bound(i,1)+Xtemp/(2^M-1)*(bound(i,2)-bound(i,1)); 
    Xtemp=0;
end 
%}
end
X_data=X_data(2:Dim*k+1);
