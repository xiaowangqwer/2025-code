function [distanceMatrix] = shuxing_juli(data)
% 步骤1: 计算每个属性下任意两个属性值之间的距离
numAttributes = size(data, 2); % 获取数据的属性个数
distanceMatrix = zeros(numAttributes); % 初始化距离矩阵，用于存储每个属性下不同属性值之间的距离

for i = 1:numAttributes % 遍历每个属性
    uniqueValues = unique(data(:, i)); % 获取当前属性的所有唯一值
    for j = 1:length(uniqueValues) % 遍历当前属性的唯一值
        for l = j + 1:length(uniqueValues) % 计算两两唯一值之间的距离（避免重复计算，因为距离是对称的）
            p = uniqueValues(j); % 取第一个值
            q = uniqueValues(l); % 取第二个值
            X = find(data(:, i) == p); % 找到数据中当前属性值为p的对象索引
            Y = find(data(:, i) == q); % 找到数据中当前属性值为q的对象索引
            U = 1:size(data, 1); % 定义论域，即所有对象的索引
            mu_X = zeros(size(U)); % 初始化属性值p的粗糙隶属度向量
            mu_Y = zeros(size(U)); % 初始化属性值q的粗糙隶属度向量
            for m = 1:length(U) % 遍历论域中的每个对象
                mu_X(m) = length(intersect(X, find(data(m, :) == data(U(m), :)))) / length(find(data(m, :) == data(U(m), :)));
                % 计算对象m对于属性值p的粗糙隶属度，分子是对象m在其他属性上与属性值为p的对象相同的个数，分母是对象m在其他属性上相同的对象总数
                mu_Y(m) = length(intersect(Y, find(data(m, :) == data(U(m), :)))) / length(find(data(m, :) == data(U(m), :)));
                % 计算对象m对于属性值q的粗糙隶属度
            end
            delta_a_j = sum(abs(mu_X - mu_Y)) / length(U); % 计算属性值p和q相对于当前属性i的外部距离
            distanceMatrix(i, j) = delta_a_j; % 将计算得到的距离存入距离矩阵
            distanceMatrix(i, l) = delta_a_j; % 因为距离对称，同时存入对称位置
        end
    end
end