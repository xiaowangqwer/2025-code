%参考文献：A powerful and efficient algorithm for numerical function optimization: artificial bee colony (ABC) algorithm. Kluwer Academic Publishers, 2007, 39(3):459-471.
clear;clc;%清除缓存
tic;
global Dim Walk_Dim D D_mod k
%{
% 所有列范围相同
data = randi([0, 4], 20, 4);

%[data, ~] = xlsread('your_data_file.xlsx'); % 根据实际情况读取数据
k = 3; % 假设聚类个数为3
max_iter = 100; % 最大迭代次数
[cluster_labels, centroids] = new2_Kmodes(data, k, max_iter);
%}
% 生成分类数据集
%data = randi(7,40,2);

temp_vote=readtable('lung-cancer.txt');
%
datalabel=zeros(434,1);
temp_vote=readtable('house-votes-84.txt');
for i=1:434
    if strcmp(temp_vote{i,1}, 'republican')
      datalabel(i,1)=1;
    else
      datalabel(i,1)=2;
    end
    for j=1:17
    if strcmp(temp_vote{i,j}, 'n')
        temp_data(i,j)=0;
    elseif strcmp(temp_vote{i,j}, 'y')
        temp_data(i,j)=1;
    elseif strcmp(temp_vote{i,j}, '?')
        temp_data(i,j)=0; 
    end
    end
end
%temp_data(any(temp_data == 3, 2), :) = [];
data=temp_data(:,2:17);
%}
numP=size(data,1);
Dim=size(data,2);
bianma_length=0; 
weidu_juzhen=zeros(1,Dim); %记录数据每一维的数据的编码长度
for i=1:Dim
    bound(i,:)=[min(data(:,i)) max(data(:,i))];
    if bound(i,2)<2
        bianma_length=bianma_length+1;
        weidu_juzhen(1,i)=1;
    elseif bound(i,2)>=2 && bound(i,2)<4
        bianma_length=bianma_length+2;
        weidu_juzhen(1,i)=2;
    elseif bound(i,2)>=4 && bound(i,2)<8
        bianma_length=bianma_length+3;
        weidu_juzhen(1,i)=3;
    end
end
k = 2;
%[cx,cost] = kmodes(k,data,datalabel);
gy_size=50;  %雇佣蜂群的大小
gc_size=50;  %观察蜂群的大小
Walk_Dim=3;  
D=floor(bianma_length/Walk_Dim);
D_mod=mod(bianma_length*k,Walk_Dim);
limit=2;%round(0.2*Dim*gy_size);  %蜜源实验限制，判断侦查蜂阶段
max_gen=15;  %最大迭代次数
% pop_max=10;   %蜜源边界，蜜源=位置
% pop_min=-10;
% bound=[-10 10];
% fun_num=1; %测试函数中目标函数索引
cost_temp=0;
%% 初始化种群
 %while cost_temp==0
 thea=rand(gy_size,Dim*k)*2*pi;
min_thea=min(thea(:));
max_thea=max(thea(:));
bee_population=zeros(2*gy_size,Dim*k);
for i=1:gy_size
    x=2*i-1;
    for j=1:Dim*k
       bee_population(x,j)=cos(thea(i,j));
       bee_population(x+1,j)=sin(thea(i,j));
    end
end
 %poplulation_quan=InitPop(gy_size*2,bianma_length*k);  %初始化种群，初始为雇佣蜂角色
 poplulation_bin=collapse(bee_population);
 centr=zeros(1,Dim*k);
 pbest_fit = zeros(gy_size, 1)+9999;           % 初始化每个个体的历史最佳适应度 
 for ip=1:gy_size
    solutions(ip,:)=bin2decFun_kmodes(poplulation_bin(ip,:),k,weidu_juzhen,bianma_length);
    centr=solutions(ip,:);
    [min_dist, cluster]=calcu_len(centr,data,numP);
    cost(ip)=min_dist;% 计算个体当前适应度
        if pbest_fit(ip) > cost(ip) 
            pbest_fit(ip) = cost(ip); % 更新个体历史最佳适应度
            pbest_bin(ip,:) = poplulation_bin(ip,:);    % 更新个体历史最佳位置 
        end 
    total_cluster(ip,:)=cluster;
 end
 
[min_cost,index]=min(cost);  %最小函数值及其索引
[max_cost,~]=max(cost);
%best_pop=poplulation(index,:);    %最优蜜源
gbest_bin=poplulation_bin(index,:);   %群体历史最优位置（蜜源）
gbest_fit=min_cost;                   %群体历史最优适应度
min_fit=max_cost;
best_point=solutions(index,:);
L=zeros(gy_size,1); %蜜源位置更新停滞的次
LL=zeros(gy_size,1); %侦查蜂更新停滞的次数
gen=1;
record(gen,:)=[gen,gbest_fit];
disp(['Generation ' num2str(gen) '   Max cost= ' num2str(gbest_fit)]);
%% 雇佣蜂阶段
reduce_gy_size=gy_size;
for gen=2:max_gen
    %%划分精英种群和非精英种群
    [~,ind]=sort(cost);
    %[~, ind] = sort(cost, 'descend'); 
    LOSER=ind(1:reduce_gy_size);
    WINNER= ind(reduce_gy_size+1:gy_size);
    for ip=1:gy_size
        poplulation_bin_gy=poplulation_bin(ip,:);
       % poplulation_quan_gy=Qgate(poplulation_quan_gy,poplulation_bin_gy,cost,best_bin,best_fit);
       %%%%%%%%%%%%%%同时游走+拼接%%%%%%
%         poplulation_bin(ip,:)=Qwalk_vbest(poplulation_bin_gy,best_bin); 
%         new_poplulation_bin=poplulation_bin(ip,:);
        %%%%%%%%%游走后判断是否更新 
        if ismember(ip, WINNER)
        [new_poplulation_bin,centr,new_cost,cluster]=Qwalk_kmodes(poplulation_bin_gy,pbest_bin,data,numP,weidu_juzhen,bianma_length);
        else
        [new_poplulation_bin,centr,new_cost,cluster]=Qwalk_kmodes(poplulation_bin_gy,gbest_bin,data,numP,weidu_juzhen,bianma_length);
        end
       %%%%%%%%%%%分别游走?+拼接原比特%%%%%%% 
%        new_poplulation_bin=Qwalk(poplulation_bin_gy);
%         for ni=1:D
%        massvalue(ni)=new_poplulation_bin(ni,:)*mass;%%%%%%%%%%%%%%计算总质量
%        if massvalue(ni)<limit0
%         new_cost(ni)=new_poplulation_bin(ni,:)*price;%%%%%%%%%%%%%%总质量低于40则适应度即价值
%        else
%         new_cost(ni)=0;%%%%%%%%%%%%%%%%%%%%否则适应度为0
%        end
%         end
%      [walk_max_newcost,walk_new_index]=max(new_cost); %取多个游走最大结果
%%%%%%%%%%%%计算适应度%%%%%%
%        massvalue(ip)=new_poplulation_bin*mass;%%%%%%%%%%%%%%计算总质量
%        if massvalue(ip)<=limit0
%         new_cost(ip)=new_poplulation_bin*price;%%%%%%%%%%%%%%总质量低于40则适应度即价值
%        else
%         new_cost(ip)=0.01;%%%%%%%%%%%%%%%%%%%%否则适应度为0
%        end
    %end
%       
        if new_cost<cost(ip)      %贪婪方式存储最佳蜜源，若没更新，则记录
%             poplulation_quan(2*ip-1,:)=poplulation_quan_gy(1,:);
%             poplulation_quan(2*ip,:)=poplulation_quan_gy(2,:);
            solutions(ip,:)=centr;
            poplulation_bin(ip,:)=new_poplulation_bin;
            cost(ip)=new_cost;
            if pbest_fit(ip) >  cost(ip) 
            pbest_fit(ip) = cost(ip); % 更新个体历史最佳适应度
            pbest_bin(ip,:) = poplulation_bin(ip,:);    % 更新个体历史最佳位置 
            end 
            total_cluster(ip,:)=cluster;
%             if new_cost(ip)>best_fit
%                 best_fit=new_cost(ip);
%                 best_bin=new_poplulation_bin;
%             end
        else
            L(ip)=L(ip)+1;      %记录此蜜源的更新停滞次数
        end
    end
    %计算适应性
    m_cost=mean(cost);
    for i=1:gy_size
        F(i)=exp(-cost(i)/m_cost);
    end  
    P=cumsum(F/sum(F));    %更新累积选择概率
%% 观察蜂阶段
    for i=1:gc_size
        %%%%轮盘赌策略
         %{
         r=rand;   % 采用轮盘赌随机选择一个蜜源,对该蜜源进行更新
         j=find(r<=P,1,'first');
         poplulation_bin_gc=poplulation_bin(j,:);
         %}
        %%%%%%%%%%传统锦标赛%%%%%%%%
        %
        TN=2;
        r=randi([1 20],1,TN);
        if cost(r(1))>cost(r(2))
            j=r(1);
        poplulation_bin_gc=poplulation_bin(r(1),:);
        else
            j=r(2);
        poplulation_bin_gc=poplulation_bin(r(2),:);
        end
        %}
        %poplulation_quan_gc=Qgate(poplulation_quan_gc,poplulation_bin_gc,cost,best_bin,best_fit);
        %new_poplulation_bin=collapse(poplulation_quan_gc);
        if ismember(ip, WINNER)
        [new_poplulation_bin_gc, centr,new_cost_gc,cluster]=Qwalk_kmodes(poplulation_bin_gc,pbest_bin,data,numP,weidu_juzhen,bianma_length);
        else
        [new_poplulation_bin_gc, centr,new_cost_gc,cluster]=Qwalk_kmodes(poplulation_bin_gc,gbest_bin,data,numP,weidu_juzhen,bianma_length);    
        end
        %new_poplulation=bin2decFun(new_poplulation_bin,bound);
      %[walk_max_newcost,walk_new_index]=max(new_cost); %取多个游走最大结果

        if new_cost_gc<cost(j)      %贪婪方式存储最佳蜜源，若没更新，则记录
%             poplulation_quan(2*ip-1,:)=poplulation_quan_gc(1,:);
%             poplulation_quan(2*ip,:)=poplulation_quan_gc(2,:);
            solutions(j,:)=centr;
            poplulation_bin(j,:)=new_poplulation_bin_gc;
            cost(j)=new_cost_gc;
            if pbest_fit(j) >  cost(j) 
            pbest_fit(j) = cost(j); % 更新个体历史最佳适应度
            pbest_bin(j,:) = poplulation_bin(j,:);    % 更新个体历史最佳位置 
            end 
            total_cluster(j,:)=cluster;
%             if new_cost_gc(i)>best_fit
%                 best_fit=new_cost_gc(i);
%                 best_bin=new_poplulation_bin_gc;
%             end           
        else
            L(i)=L(i)+1;      %记录此蜜源的更新停滞次数
        end
                      %更新相应的函数值
%         [zc_walk_max_newcost,zc_walk_new_index]=max(cost); %取多个游走最大结果
% 
% %        new_best_pop=new_poplulation(new_index,:);    %最优蜜源
%        new_best_bin=new_poplulation_bin(zc_walk_new_index,:);
%        new_best_fit=wal_max_newcost; 
    end
    
    %% 侦查蜂阶段
    for i=1:gy_size    %遍历种群看是否有蜜源停滞更新
        if L(i)>=limit
            temp_new_poplulation_bin_zc=round(rand(1,bianma_length*k)*1);
            %poplulation_bin(i,:)=(pop_max-pop_min).*rand(1,Dim)+pop_min;
            for j=1:k*Dim
           temp_bee_population(1,j)=(max(bee_population(:,j))-min(bee_population(:,j)))*rand+min(bee_population(:,j));%cos(thea(y,j));
           temp_bee_population(2,j)=(max(bee_population(:,j))-min(bee_population(:,j)))*rand+min(bee_population(:,j));%sin(thea(y,j));
            end
            %{
            new_bin_population=collapse(temp_bee_population);
            new_bee_population=QABC_Qgate_gc(temp_bee_population,new_bin_population,cost(i),best_bin,best_fit,numP,min_thea,max_thea,min_fit);
            new_bin_population=collapse(new_bee_population);
            %}
            new_quan_population=QABC_Qgate_zc(temp_bee_population,cost(i),gbest_fit,min_fit,numP,min_thea,max_thea);
            new_bin_population=collapse(new_quan_population);
            new_poplulation_bin_zc=gbest_bin&new_bin_population;%解与最好的解进行与运算
            centr=bin2decFun_kmodes(new_poplulation_bin_zc,k,weidu_juzhen,bianma_length);
            [min_dist, cluster]=calcu_len(centr,data,numP);
            
           if min_dist<cost(i)
            poplulation_bin(i,:)=new_poplulation_bin_zc;
            cost(i)=min_dist;
            if pbest_fit(i) > cost(i) 
            pbest_fit(i) = cost(i); % 更新个体历史最佳适应度
            pbest_bin(i,:) = poplulation_bin(i,:);    % 更新个体历史最佳位置 
            end 
            total_cluster(i,:)=cluster;
            solutions(i,:)=centr;
            L(i)=0;
           else
            LL(i)=LL(i)+1;
           end     
        end
        if LL(i)>2
            cost(i)=min_dist;
            poplulation_bin(i,:)=new_poplulation_bin_zc;
            pbest_fit(i) = cost(i); % 更新个体历史最佳适应度
            pbest_bin(i,:) = poplulation_bin(i,:);    % 更新个体历史最佳位置 
            total_cluster(i,:)=cluster;
            solutions(i,:)=centr;
            LL(i)=0;
        end
    end
    
    %% 完成一代的更新
    for i=1:gy_size
        if cost(i)<gbest_fit
            gbest_bin=poplulation_bin(i,:);
            gbest_fit=cost(i);
            best_point=solutions(i,:);
            best_cluster=total_cluster(i,:);
        end

    end
    min_fit=max(cost);
    %max_cost=best_fit;
    %[accuracy,conMtx]=CA(best_cluster',datalabel);
    record(gen,:)=[gen,gbest_fit];
    disp(['Generation ' num2str(gen) '   Max cost= ' num2str(gbest_fit)]);
    n_c=gy_size/3+max_gen-gen;
    reduce_gy_size=round((((gy_size-n_c)*gen)/(1-max_gen)) + gy_size- (gy_size-n_c)/(1-max_gen));
end
centrs=best_point;
[cluster,centr,record2,add_Generation,accuracy]=QABC_kModes_data(k,data,centrs,gen,datalabel);
record(gen+1:gen+add_Generation,2)=record2(gen+1:gen+add_Generation,2);
record(gen+1:gen+add_Generation,1)=record2(gen+1:gen+add_Generation,1);
toc
disp(['运行时间: ',num2str(toc)]);
%绘图
figure('Name','Visualizations','units','normalized','outerposition',[0 0 1 1]);
subplot(2,2,1);
plot(record(:,1),record(:,2));
xlabel('iteration');
ylabel('SSE');
%聚类准确度 真实的划分 
% visualize the clustering
centeriod=zeros(3,3);
centeriod(1,:)=centr(1,1:3);
centeriod(2,:)=centr(1,5:7);
centeriod(3,:)=centr(1,9:11);
subplot(2,2,2);
scatter3(xP,yP,zP,length(dataset),cluster,'.');
hold on;
scatter3(centeriod(1,:),centeriod(1,:),centeriod(1,:),'xk','LineWidth',1.5);
axis([0 10 0 10 0 10]);
daspect([1 1 1]);
xlabel('x');
ylabel('y');
title('Random data points clustered (qwkmeans)');
grid on;

subplot(2,2,3);
histogram(cluster);
axis tight;
[num,~] = histcounts(cluster);
yticks(round(linspace(0,max(num),k)));
xlabel('Clusters');
ylabel('Number of data points');
title('Histogram of the cluster points (qwkmeans)');
%}