%参考文献：A powerful and efficient algorithm for numerical function optimization: artificial bee colony (ABC) algorithm. Kluwer Academic Publishers, 2007, 39(3):459-471.
clear;clc;%清除缓存
global Dim D
gy_size=40;  %雇佣蜂群的大小
gc_size=40;  %观察蜂群的大小
bianma_length=0; 
weidu_juzhen=zeros(1,Dim); %记录数据每一维的数据的编码长度
%{
datalabel=zeros(434,1);
temp_vote=readtable('house-votes-84.txt');
for i=1:434
    if strcmp(temp_vote{i,1}, 'republican')
      datalabel(i,1)=1;
    else
      datalabel(i,1)=2;
    end
    for j=1:17
    if strcmp(temp_vote{i,j}, 'n')
        temp_data(i,j)=0;
    elseif strcmp(temp_vote{i,j}, 'y')
        temp_data(i,j)=1;
    elseif strcmp(temp_vote{i,j}, '?')
        temp_data(i,j)=0; 
    end
    end
end
%temp_data(any(temp_data == 3, 2), :) = [];
data=temp_data(:,2:17);
Dim=size(data,2);
for i=1:Dim
    bound(i,:)=[min(data(:,i)) max(data(:,i))];
    if bound(i,2)<2
        bianma_length=bianma_length+1;
        weidu_juzhen(1,i)=1;
    elseif bound(i,2)>=2 && bound(i,2)<4
        bianma_length=bianma_length+2;
        weidu_juzhen(1,i)=2;
    elseif bound(i,2)>=4 && bound(i,2)<8
        bianma_length=bianma_length+3;
        weidu_juzhen(1,i)=3;
    end
end
%}

%{
temp_tic=readtable('tic-tac-toe.txt');
datalabel(1:625,1)=1;
datalabel(625:957,1)=2;
for i=1:957
    for j=1:9
    if strcmp(temp_tic{i,j}, 'b')
        temp_data(i,j)=0;
    elseif strcmp(temp_tic{i,j}, 'x')
        temp_data(i,j)=1;
    elseif strcmp(temp_tic{i,j}, 'o')
        temp_data(i,j)=2; 
    end
    end
end
data=temp_data(:,1:9);
Dim=size(data,2);
for i=1:Dim
    bound(i,:)=[min(data(:,i)) max(data(:,i))];
    if bound(i,2)<2
        bianma_length=bianma_length+1;
        weidu_juzhen(1,i)=1;
    elseif bound(i,2)>=2 && bound(i,2)<4
        bianma_length=bianma_length+2;
        weidu_juzhen(1,i)=2;
    elseif bound(i,2)>=4 && bound(i,2)<8
        bianma_length=bianma_length+3;
        weidu_juzhen(1,i)=3;
    end
end
%}

%{
datalabel=zeros(267,1);
A=readtable('SPECT.txt');
temp_Spect=table2array(A);
for i=1:267
    if temp_Spect(i,23)==0
      datalabel(i,1)=1;
    else
      datalabel(i,1)=2;
    end
end
%temp_data(any(temp_data == 3, 2), :) = [];
data=temp_Spect(:,1:22);
Dim=size(data,2);
for i=1:Dim
    bound(i,:)=[min(data(:,i)) max(data(:,i))];
    if bound(i,2)<2
        bianma_length=bianma_length+1;
        weidu_juzhen(1,i)=1;
    elseif bound(i,2)>=2 && bound(i,2)<4
        bianma_length=bianma_length+2;
        weidu_juzhen(1,i)=2;
    elseif bound(i,2)>=4 && bound(i,2)<8
        bianma_length=bianma_length+3;
        weidu_juzhen(1,i)=3;
    end
end
%}

%{
datalabel=zeros(1728,1);
temp_car=readtable('car.txt');
for i=1:1728
    if strcmp(temp_car{i,7}, 'unacc')
      datalabel(i,1)=1;
    elseif strcmp(temp_car{i,7}, 'acc')
      datalabel(i,1)=2;
    elseif strcmp(temp_car{i,7}, 'good')
      datalabel(i,1)=3;
    else
      datalabel(i,1)=4;
    end
    
    if strcmp(temp_car{i,1}, 'low') 
        temp_data(i,1)=0;
    elseif strcmp(temp_car{i,1}, 'med')
        temp_data(i,1)=1;
    elseif strcmp(temp_car{i,1}, 'high')
        temp_data(i,1)=2;
    elseif strcmp(temp_car{i,1}, 'vhigh')
        temp_data(i,1)=3;
    end
   
    if  strcmp(temp_car{i,2}, 'low')
        temp_data(i,2)=0;
    elseif strcmp(temp_car{i,2}, 'med')
        temp_data(i,2)=1;
    elseif strcmp(temp_car{i,2}, 'high')
        temp_data(i,2)=2;
    elseif strcmp(temp_car{i,2}, 'vhigh')
        temp_data(i,2)=3;
    end

    if temp_car{i,3} == 2
        temp_data(i,3) = 0;
    elseif temp_car{i,3} == 3
        temp_data(i,3) = 1;
    elseif temp_car{i,3} == 4
        temp_data(i,3) = 2;
    elseif isnan(temp_car{i,3})  % 使用 isnan 检查 NaN 值
        temp_data(i,3) = 3;
    end

    if temp_car{i,4} == 2
        temp_data(i,4) = 0;
    elseif temp_car{i,4} == 4
        temp_data(i,4) = 1;
    elseif isnan(temp_car{i,4})
        temp_data(i,4) = 2;
    end

    if  strcmp(temp_car{i,5}, 'small')
        temp_data(i,5)=0;
    elseif strcmp(temp_car{i,5}, 'med')
        temp_data(i,5)=1;
    elseif strcmp(temp_car{i,5}, 'big')
        temp_data(i,5)=2;
    end

    if  strcmp(temp_car{i,6}, 'low')
        temp_data(i,6)=0;
    elseif strcmp(temp_car{i,6}, 'med')
        temp_data(i,6)=1;
    elseif strcmp(temp_car{i,6}, 'high')
        temp_data(i,6)=2;
    end
end
data=temp_data(:,1:6);
Dim=size(data,2);
for i=1:Dim
    bound(i,:)=[min(data(:,i)) max(data(:,i))];
    if bound(i,2)<2
        bianma_length=bianma_length+1;
        weidu_juzhen(1,i)=1;
    elseif bound(i,2)>=2 && bound(i,2)<4
        bianma_length=bianma_length+2;
        weidu_juzhen(1,i)=2;
    elseif bound(i,2)>=4 && bound(i,2)<8
        bianma_length=bianma_length+3;
        weidu_juzhen(1,i)=3;
    end
end
%}

%
datalabel=zeros(148,1);
temp_lym=readtable('lymphography.txt');
datalabel(:,1)=table2array(temp_lym(:,1));
data=table2array(temp_lym(:,2:19))-1;
Dim=size(data,2);
for i=1:Dim
    bound(i,:)=[min(data(:,i)) max(data(:,i))];
    if bound(i,2)<2
        bianma_length=bianma_length+1;
        weidu_juzhen(1,i)=1;
    elseif bound(i,2)>=2 && bound(i,2)<4
        bianma_length=bianma_length+2;
        weidu_juzhen(1,i)=2;
    elseif bound(i,2)>=4 && bound(i,2)<8
        bianma_length=bianma_length+3;
        weidu_juzhen(1,i)=3;
    end
end
%}
numP=size(data,1);
k=2;
%[cx,cost] = kmodes(k,data,datalabel);
D=3;
limit=2;%round(0.2*Dim*gy_size);  %蜜源实验限制，判断侦查蜂阶段
max_gen=20;  %最大迭代次数
%% 初始化种群
thea=rand(gy_size,bianma_length*k)*2*pi;
min_thea=min(thea(:));
max_thea=max(thea(:));
bee_population=zeros(2*gy_size,bianma_length*k);
for i=1:gy_size
    x=2*i-1;
    for j=1:bianma_length*k
       bee_population(x,j)=cos(thea(i,j));
       bee_population(x+1,j)=sin(thea(i,j));
    end
end
 %poplulation_quan=InitPop(gy_size*2,bianma_length*k);  %初始化种群，初始为雇佣蜂角色
 poplulation_bin=collapse(bee_population);
 centr=zeros(1,Dim*k);
 %
 %tic
 A=[0,0;0,1;1,0];
 for j=1:gy_size
 for i=1:bianma_length
     u=2*i-1;
     if poplulation_bin(j,u)==1 && poplulation_bin(j,u+1)==1
        poplulation_bin(j,u:u+1)=A(randi([1,3]),:);
     end
 end
 end
 %}

 %{
 %car
 A=[0,0;0,1;1,0];
 for j=1:gy_size
 i=7;
 while i<bianma_length
     if poplulation_bin(j,i)==1 && poplulation_bin(j,i+1)==1
        poplulation_bin(j,i:i+1)=A(randi([1,3]),:);
     end
     i=i+1;
 end
 i=19;
 while i<bianma_length*2
     if poplulation_bin(j,i)==1 && poplulation_bin(j,i+1)==1
        poplulation_bin(j,i:i+1)=A(randi([1,3]),:);
     end
     i=i+1;
 end
 i=31;
 while i<bianma_length*3
     if poplulation_bin(j,i)==1 && poplulation_bin(j,i+1)==1
        poplulation_bin(j,i:i+1)=A(randi([1,3]),:);
     end
     i=i+1;
 end
 i=43;
 while i<bianma_length*k
     if poplulation_bin(j,i)==1 && poplulation_bin(j,i+1)==1
        poplulation_bin(j,i:i+1)=A(randi([1,3]),:);
     end
     i=i+1;
 end
 end
 %}

 %{
 %lym
 A=[0,0;0,1;1,0];
 for j=1:gy_size
 i=14;
     if poplulation_bin(j,i)==1 && poplulation_bin(j,i+1)==1
        poplulation_bin(j,i:i+1)=A(randi([1,3]),:);
     end
 i=23;
     if poplulation_bin(j,i)==1 && poplulation_bin(j,i+1)==1
        poplulation_bin(j,i:i+1)=A(randi([1,3]),:);
     end
 i=43;
     if poplulation_bin(j,i)==1 && poplulation_bin(j,i+1)==1
        poplulation_bin(j,i:i+1)=A(randi([1,3]),:);
     end
 i=52;
     if poplulation_bin(j,i)==1 && poplulation_bin(j,i+1)==1
        poplulation_bin(j,i:i+1)=A(randi([1,3]),:);
     end
 i=72;
     if poplulation_bin(j,i)==1 && poplulation_bin(j,i+1)==1
        poplulation_bin(j,i:i+1)=A(randi([1,3]),:);
     end
 i=81;
     if poplulation_bin(j,i)==1 && poplulation_bin(j,i+1)==1
        poplulation_bin(j,i:i+1)=A(randi([1,3]),:);
     end
 i=101;
     if poplulation_bin(j,i)==1 && poplulation_bin(j,i+1)==1
        poplulation_bin(j,i:i+1)=A(randi([1,3]),:);
     end
 i=109;
     if poplulation_bin(j,i)==1 && poplulation_bin(j,i+1)==1
        poplulation_bin(j,i:i+1)=A(randi([1,3]),:);
     end
 end
 %}
 for ip=1:gy_size
 solutions(ip,:)=bin2decFun_kmodes(poplulation_bin(ip,:),k,weidu_juzhen,bianma_length);
    centr=solutions(ip,:);
    [min_dist, cluster]=calcu_len(centr,data,numP);
    cost(ip)=min_dist;% 计算个体当前适应度 
    total_cluster(ip,:)=cluster;
 end
 %计算对应的函数值
[min_cost,index]=min(cost); %最小函数值及其索引
%best_pop=poplulation(index,:);    %最优蜜源
best_bin=poplulation_bin(index,:);
best_fit=min_cost;
best_point=solutions(index,:);
L=zeros(gy_size,1);      %蜜源位置更新停滞的次数
LL=zeros(gy_size,1);
gen=1;
record(gen,:)=[gen,best_fit];
disp(['Generation ' num2str(gen) '   Max cost= ' num2str(best_fit)]);
%% 雇佣蜂阶段
for gen=2:max_gen
    for ip=1:gy_size
        poplulation_quan_gy=[bee_population(2*ip-1,:);bee_population(2*ip,:)];
        poplulation_bin_gy=poplulation_bin(ip,:);
        poplulation_quan_gy=Qgate(poplulation_quan_gy,poplulation_bin_gy,cost,best_bin,best_fit);
        new_poplulation_bin=collapse(poplulation_quan_gy);
        centr=bin2decFun_kmodes(new_poplulation_bin,k,weidu_juzhen,bianma_length);
        [min_dist, cluster]=calcu_len(centr,data,numP);
      %[min_newcost,new_index]=min(new_cost); %最小函数值及其索引
%        new_best_pop=new_poplulation(new_index,:);    %最优蜜源
%       new_best_bin=new_poplulation_bin(new_index,:);
%       new_best_fit=min_newcost; 
        if min_dist<cost(ip)      %贪婪方式存储最佳蜜源，若没更新，则记录
            bee_population(2*ip-1,:)=poplulation_quan_gy(1,:);
            bee_population(2*ip,:)=poplulation_quan_gy(2,:);
            poplulation_bin(ip,:)=new_poplulation_bin;
            total_cluster(ip,:)=cluster;
            solutions(ip,:)=centr;
            cost(ip)=min_dist;
        else
            L(ip)=L(ip)+1;      %记录此蜜源的更新停滞次数
        end
    end
    %计算适应性
    m_cost=mean(cost);
    for i=1:gy_size
        F(i)=exp(-cost(i)/m_cost);
    end
    
    P=cumsum(F/sum(F));    %更新累积选择概率
   

    %% 观察蜂阶段
    for i=1:gc_size
        r=rand;   % 采用轮盘赌随机选择一个蜜源,对该蜜源进行更新
        j=find(r<=P,1,'first');
        poplulation_quan_gc=[bee_population(2*j-1,:);bee_population(2*j,:)];
        poplulation_bin_gc=poplulation_bin(j,:);
        poplulation_quan_gc=Qgate(poplulation_quan_gc,poplulation_bin_gc,cost,best_bin,best_fit);
        new_poplulation_bin=collapse(poplulation_quan_gc);
        centr=bin2decFun_kmodes(new_poplulation_bin,k,weidu_juzhen,bianma_length);
        [min_dist, cluster]=calcu_len(centr,data,numP);
    
      %[min_newcost,new_index]=min(new_cost); %最小函数值及其索引
%        new_best_pop=new_poplulation(new_index,:);    %最优蜜源
%       new_best_bin=new_poplulation_bin(new_index,:);
%       new_best_fit=min_newcost; 
        if min_dist<cost(j)      %贪婪方式存储最佳蜜源，若没更新，则记录
            bee_population(2*j-1,:)=poplulation_quan_gc(1,:);
            bee_population(2*j,:)=poplulation_quan_gc(2,:);
            poplulation_bin(j,:)=new_poplulation_bin;
            total_cluster(j,:)=cluster;
            solutions(j,:)=centr;
            cost(j)=min_dist;
        else
            L(i)=L(i)+1;      %记录此蜜源的更新停滞次数
        end
                      %更新相应的函数值
        
    end
    
    %% 侦查蜂阶段
    for i=1:gy_size    %遍历种群看是否有蜜源停滞更新
        if L(i)>=limit
            for j=1:k*bianma_length
           temp_bee_population(1,j)=(max(bee_population(:,j))-min(bee_population(:,j)))*rand+min(bee_population(:,j));%cos(thea(y,j));
           temp_bee_population(2,j)=(max(bee_population(:,j))-min(bee_population(:,j)))*rand+min(bee_population(:,j));%sin(thea(y,j));
            end
            new_poplulation_bin_zc=collapse(temp_bee_population);
            centr=bin2decFun_kmodes(new_poplulation_bin_zc,k,weidu_juzhen,bianma_length);
            [min_dist, cluster]=calcu_len(centr,data,numP);
            
            if min_dist<cost(i)
            bee_population(i:i+1,:)=temp_bee_population;
            poplulation_bin(i,:)=new_poplulation_bin_zc;
            cost(i)=min_dist;
            total_cluster(i,:)=cluster;
            solutions(i,:)=centr;
            L(i)=0;
            else
            LL(i)=LL(i)+1;
            end
        end
        if LL(i)>2
            cost(i)=min_dist;
            poplulation_bin(i,:)=new_poplulation_bin_zc;
            bee_population(i:i+1,:)=temp_bee_population;
            total_cluster(i,:)=cluster;
            solutions(i,:)=centr;
            LL(i)=0;
        end
    end
    
    %% 完成一代的更新
    for i=1:gy_size
        if cost(i)<best_fit
            best_bin=poplulation_bin(i,:);
            best_fit=cost(i);
            best_point=solutions(i,:);
            best_cluster=total_cluster(i,:);
        end
    end
    %记录
    %record(gen,:)=[gen,best_fit];
    %disp(['Generation ' num2str(gen) '   Min cost= ' num2str(best_fit)]);
end
centrs=best_point;
%[cluster,centr,record2,add_Generation,accuracy]=QABC_kModes_data_vote(k,data,centrs,gen,datalabel);
%[cluster,centr,record2,add_Generation,accuracy]=QABC_kModes_data_tic(k,data,centrs,gen,datalabel);
%[cluster,centr,record2,add_Generation,accuracy]=QABC_kModes_data_Spect(k,data,centrs,gen,datalabel);
[cluster,centr,record2,add_Generation,accuracy]=QABC_kModes_data_lym(k,data,centrs,gen,datalabel);
record(gen+1:gen+add_Generation,2)=record2(gen+1:gen+add_Generation,2);
record(gen+1:gen+add_Generation,1)=record2(gen+1:gen+add_Generation,1);
toc
disp(['运行时间: ',num2str(toc)]);
%绘图
figure('Name','Visualizations','units','normalized','outerposition',[0 0 1 1]);
subplot(2,2,1);
plot(record(:,1),record(:,2));
xlabel('iterations');
ylabel('SSE');
