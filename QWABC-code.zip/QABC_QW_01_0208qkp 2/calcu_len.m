
function [min_dist, cluster]=calcu_len(centr,points,numP)
global k Dim
%centr = points(:,inti_pops_temp);
min_dist=0;
centrs = reshape(centr, Dim, k).';
for idxP = 1:numP
        % init distance array dist 初始距离数组
        %dist = zeros(1,k);
        % compute distance to each centroid计算到每个中心点的距离
        %for idxC=1:k
        %l=Dim*idxC-(Dim-1);    
        % 汉明距离
        [min_dist_temp,cluster_temp] = min(sum((points(idxP,:)~=centrs)'));
        min_dist=min_dist+min_dist_temp;
        cluster(idxP)=cluster_temp;
        %end

end
end