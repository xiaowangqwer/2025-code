function centroids = compueCentroids(data,cx,K)
% 计算新的聚类中心
    centroids = zeros(K,size(data,2));
    for i = 1:K
%       众数为聚类中心
        centroids(i,:) = mode(data(cx==i,:));
    end
end