function [clusters, modes] = new2_Kmodes(data, k, max_iter)
    % 基于新距离度量的 K-Modes 聚类算法
    % 输入:
    %   data - 分类数据矩阵 (n x m)，其中 n 是样本数，m 是特征数
    %   k - 聚类数
    %   max_iter - 最大迭代次数
    % 输出:
    %   clusters - 每个样本的聚类分配结果
    %   modes - 每个聚类的中心（Mode）
    
    [n, m] = size(data);  % 获取样本数量 n 和特征数量 m
    % 随机初始化 k 个聚类中心
    %rand_indices = randperm(n, k);  % 随机选择 k 个样本索引作为初始中心
    modes = data([5 6], :); % 将这 k 个样本作为初始聚类中心
    min_dist=0;
    clusters = zeros(n, 1);  % 初始化每个样本的聚类分配结果，默认为 0
    for iter = 1:max_iter
        % 第一步: 根据新距离度量将每个样本分配到最近的聚类
        for i = 1:n
            distances = zeros(1, k);  % 初始化当前样本到所有聚类中心的距离
            for j = 1:k
                distances(j) = new_distance(data(i, :), modes(j, :), data,m); % 计算到第 j 个中心的距离
            end
            [min_dist_temp, clusters(i)] = min(distances); % 找到最小距离对应的聚类
            min_dist=min_dist+min_dist_temp;
        end
        
        % 第二步: 更新每个聚类的中心
        new_modes = modes;  % 临时存储新的聚类中心
        for j = 1:k
            cluster_data = data(clusters == j, :); % 提取属于当前聚类的数据
            if ~isempty(cluster_data)
                new_modes(j, :) = mode(cluster_data, 1); % 逐列计算众数作为新的聚类中心
            end
        end
        
        % 检查是否收敛（聚类中心不再变化）
        if isequal(new_modes, modes)
            break;  % 如果新的聚类中心和之前的相同，则退出循环
        end
        modes = new_modes;  % 更新聚类中心
    end
end
