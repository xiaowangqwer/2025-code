function new_bee_population=QABC_Qgate_zc(bee_population,cost,best_fit,min_fit,numP,min_thea,max_thea)

best_fit=best_fit/numP;
min_fit=min_fit/numP;
cost=cost/numP;
lenchrom=length(bee_population);
    for j=1:lenchrom
        A=bee_population(1,j);   % α,cos的值
        B=bee_population(2,j);     % β,sin的值
        %a=acos(A);% 反解角度大小
        b=asin(B);
        if cost<best_fit
            delta=0;
            s=1;
        else
            delta=0.2*(max_thea-min_thea)+(abs(cost/(best_fit-min_fit)))*(max_thea-min_thea);
            %delta=min_thea+((best_fit-cost)/best_fit)*(max_thea+min_thea);
            %delta=rand*(max_thea-min_thea)+(abs(cost/best_fit-min_fit))*(max_thea-min_thea);
            %delta=max_thea-(abs(best_fit-cost)/best_fit)*(max_thea+min_thea);
            if A*B>0
                s=1;
            elseif A*B<0
                s=-1;
            end
        end

        e=s*delta;       % e为旋转角  
        U=[cos(e) -sin(e);sin(e) cos(e)];      % 量子旋转门
        %y=U*[cos(a),sin(a)]';        % y为更新后的量子位
        y=U*[A B]';
        new_bee_population(1,j)=y(1);
        new_bee_population(2,j)=y(2);
    end
end