function [cx,cost,accuracy] = kmodes(K,data,datalabel)
% 生成将data聚成K类的最佳聚类
%   K为聚类数目，data为数据集,num为随机初始化次数
    %[cx,cost] = kmodes1(K,data);
  % 随机选择聚类中心
    centroids = data(randperm(size(data,1),K),:);
% 迭代聚类 
    centroids_temp = zeros(size(centroids));
    num = 1;
    while (~isequal(centroids_temp,centroids)&&num<20) 
        centroids_temp = centroids;
        [cx,cost] = findClosest(data,centroids);
        % cx([2:6,90:105,177:187],1)=1;  vote
        [accuracy,conMtx]=CA(cx',datalabel); 
        centroids = compueCentroids(data,cx,K);
        
        record(num,:)=[num,cost];
        disp(['Generation ' num2str(num) '   Max cost= ' num2str(cost)]);
        num = num+1;
    end  

toc
disp(['运行时间: ',num2str(toc)]);
%绘图
figure('Name','Visualizations','units','normalized','outerposition',[0 0 1 1]);
subplot(2,2,1);
plot(record(:,1),record(:,2));
xlabel('iterations');
ylabel('SSE');
%{    
    for i = 1:num
        [cx1,min] = kmodes1(K,data);
        if min<cost
            cost = min;
            cx = cx1;
        end
    end
%}
end