function [cluster,cost] = findClosest(data,centroids)
% 将样本划分到最近的聚类中心
    sort_1=0;
    sort_2=0;
    sort_3=0;
    cost = 0;
    n = size(data,1);
    cluster = zeros(n,1);
    for i = 1:n
%        汉明距离
        [M,I] = min(sum((data(i,:)~=centroids)'));
        cluster(i) = I;
        %{
        if I==1
            sort_1=sort_1+1;
        elseif I==2
            sort_2=sort_2+1;
        else
            sort_3=sort_3+1;
        end
        %}
        cost = cost+M;
    end
end