function  [new_poplulation_bin, centr,new_cost_temp,cluster]=Qwalk_kmodes_lym(poplulation,best_bin,data,numP,weidu_juzhen,bianma_length)
  global D D_yu D_mod  Walk_Dim k
%poplulation=[1 1 1 1 1 0 0 0 0 ];
%poplulation=[1 1 1];
 %Dim=3;
% popsize=3;
popsize=D;
%tf=floor((pi/2)*sqrt(2^Dim));
tf=3;
%best_bin=[1,0,1,1,1,1,1,1,1];
v_best=best_bin;%多比特字符串
vdest=[];%dim比特
%  vbest_m=best.binary'.*best.binary;
C0=zeros(Walk_Dim,Walk_Dim);%Grover算子矩阵
temp_S=[];
t_coin1=[];
%Spi=[];
%[pops lie]=size(poplulation);
Send=[];
Smid_temp=[];
%fais0=zeros(Dim,Dim);
for ii=1:Walk_Dim
    for jj=1:Walk_Dim
      if ii==jj
          C0(ii,jj)=2/Walk_Dim-1; 
          %fais0(ii,jj)=1/sqrt(Dim);
      else
          C0(ii,jj)=2/Walk_Dim;
      end
    end
end
Id=eye(Walk_Dim,Walk_Dim);
fais0=(1/sqrt(Walk_Dim)).*ones(Walk_Dim,1);
%C1=-Id;
%C=C0.*(Id-vbest_m)+C1.*vbest_m;
% coin0=zeros(Dim,1);
% coin1=zeros(Dim,Dim^tf,tf);
% walk_coin0=zeros(Dim,1);
% walk_coin1=zeros(Dim,Dim);

for ppi=1:popsize*k+D_yu %这个for循环是每三位为一组（共三组）   找到该三位最大概率游走到的节点
    %%初始态计算，作用硬币操作和位移操作
   for i=1:Walk_Dim %这个for循环分别取到poplulation和想要游走到的目标节点的前三位二进制串
    vsource(i)=poplulation((ppi-1)*Walk_Dim+i);
    vdest(i)=v_best((ppi-1)*Walk_Dim+i);
   end
   
   for lengthi=1:Walk_Dim
      if all(vsource==vdest)  %如果vsource和vdest一开始相同
      S(lengthi,:)=vsource;
      coin0(lengthi)=dot(-Id(lengthi,:),fais0); %dot函数求内积   %若一样，硬币算子的概率就为初始的fais0=1/根号3
      coin1(lengthi,lengthi)=coin0(lengthi);
      else
      pop_xor=vsource;
      pop_xor(lengthi)=~logical(pop_xor(lengthi));%logical将数值型转成逻辑形，~逻辑非
      S(lengthi,:)=pop_xor;         %这里得到的S是poplulation每一位取非得对应每一种结果
      if S(lengthi,:)==vdest         %判断取非后的结果是否为目标（最好）的节点一样
      coin0(lengthi)=dot(-Id(lengthi,:),fais0); %dot函数求内积   %若一样，硬币算子的概率就为初始的fais0=1/根号3
      coin1(lengthi,lengthi)=coin0(lengthi); 
      else
      coin0(lengthi)=dot(C0(lengthi,:),fais0);  %否则硬币算子的概率就为初始的fais0=1/根号3 * Grover算子矩阵
      coin1(lengthi,lengthi)=coin0(lengthi);
      end   
      end
   end

%coin_1=dot(C0,fais0); 
%开始游走
step=2;
while step<tf+1
   for walkci=1:Walk_Dim^(step-1)
     pop_xor=S(walkci,:);
     temp_coin1=coin1(:,walkci);
     for walkc1i=1:Walk_Dim
     
      temp_pop_xor=pop_xor;
      temp_pop_xor(walkc1i)=~logical(pop_xor(walkc1i));
      temp_s(walkc1i,:)=temp_pop_xor;  %用来记录移位算子S每一位对应改变后的结果，下面的if else是得到S每一位改变对应的概率
                                      %比如001，得到101 011 000三种结果正好对应超立方体上001可以到达的三个节点
      if temp_pop_xor==vdest
      walk_coin0(walkc1i)=dot(-Id(walkc1i,:),temp_coin1);
      coin01(walkc1i,walkc1i)=coin0(walkc1i);  %将coin0改成了walk_coin0
      else
      walk_coin0(walkc1i)=dot(C0(walkc1i,:),temp_coin1);
      coin01(walkc1i,walkc1i)=walk_coin0(walkc1i);
      end
     end
     
      temp_S=[temp_S;temp_s];
      t_coin1=[t_coin1 coin01];
      end
   S=temp_S;
   temp_S=[];
   coin1=t_coin1;
   t_coin1=[];
   step=step+1;
  end
 coin_000=0;coin_001=0;coin_010=0;coin_100=0;coin_110=0;coin_011=0;coin_101=0;coin_111=0;
 coincol=[0 0 0;0 0 1;0 1 0;1 0 0;1 1 0;0 1 1;1 0 1;1 1 1] ;
 %%%%% 测量%%%
   for collapsei=1:Walk_Dim^(step-1)  %第一步游走3种结果，第二步游走9种结果，第三步游走27种结果
       %coin_tol(collapsei)=dot(coin1(:,collapsei),coin1(:,collapsei)');
       %S_tol=[collapsei];
       %判断每三位为一组的移位算子S与coincol中哪种相匹配，计算该算子S的概率；移位算子S与硬币算子coin1的下标是对应的
       if S(collapsei,:)==coincol(1,:)
           coin_000=coin_000+dot(coin1(:,collapsei),coin1(:,collapsei)');
       elseif S(collapsei,:)==coincol(2,:)
           coin_001=coin_001+dot(coin1(:,collapsei),coin1(:,collapsei)');
       elseif S(collapsei,:)==coincol(3,:)
           coin_010=coin_010+dot(coin1(:,collapsei),coin1(:,collapsei)');
       elseif S(collapsei,:)==coincol(4,:)
           coin_100=coin_100+dot(coin1(:,collapsei),coin1(:,collapsei)');
       elseif S(collapsei,:)==coincol(5,:)
           coin_110=coin_110+dot(coin1(:,collapsei),coin1(:,collapsei)');
       elseif S(collapsei,:)==coincol(6,:)
           coin_011=coin_011+dot(coin1(:,collapsei),coin1(:,collapsei)');
       elseif S(collapsei,:)==coincol(7,:)
           coin_101=coin_101+dot(coin1(:,collapsei),coin1(:,collapsei)');
       elseif S(collapsei,:)==coincol(8,:)
           coin_111=coin_111+dot(coin1(:,collapsei),coin1(:,collapsei)');
       end
   end
    coin_tol=[coin_000 coin_001 coin_010 coin_100 coin_110 coin_011 coin_101 coin_111];
    [coinmax,smax]=max(coin_tol);
    coin_max(ppi)=coinmax;
    Spi(ppi,:)=coincol(smax,:);
    Send=[Send Spi(ppi,:)];
      
end
%
 A=[0,0;0,1;1,0];
 i=14;
     if Send(1,i)==1 && Send(1,i+1)==1
        Send(1,i:i+1)=A(randi([1,3]),:);
     end
 i=23;
     if Send(1,i)==1 && Send(1,i+1)==1
        Send(1,i:i+1)=A(randi([1,3]),:);
     end
 i=43;
     if Send(1,i)==1 && Send(1,i+1)==1
        Send(1,i:i+1)=A(randi([1,3]),:);
     end
 i=52;
     if Send(1,i)==1 && Send(1,i+1)==1
        Send(1,i:i+1)=A(randi([1,3]),:);
     end
 i=72;
     if Send(1,i)==1 && Send(1,i+1)==1
        Send(1,i:i+1)=A(randi([1,3]),:);
     end
 i=81;
     if Send(1,i)==1 && Send(1,i+1)==1
        Send(1,i:i+1)=A(randi([1,3]),:);
     end
 i=101;
     if Send(1,i)==1 && Send(1,i+1)==1
        Send(1,i:i+1)=A(randi([1,3]),:);
     end
 i=109;
     if Send(1,i)==1 && Send(1,i+1)==1
        Send(1,i:i+1)=A(randi([1,3]),:);
     end
 %}
if D_mod==1
  bit_temp0=[Send 0];
  bit_temp1=[Send 1];
  centr0=bin2decFun_kmodes(bit_temp0,k,weidu_juzhen,bianma_length);
  [cost0, cluster0]=calcu_len(centr0,data,numP);

  centr1=bin2decFun_kmodes(bit_temp1,k,weidu_juzhen,bianma_length);
  [cost1, cluster1]=calcu_len(centr1,data,numP);

    if cost0<=cost1
        new_poplulation_bin=bit_temp0;
        new_cost_temp=cost0;
        cluster=cluster0;
        centr=centr0;
    else 
        new_poplulation_bin=bit_temp1;
        new_cost_temp=cost1;
        cluster=cluster1;
        centr=centr1;
    end
elseif D_mod==2
bit_temp00=[Send 0 0];
bit_temp01=[Send 0 1];
bit_temp10=[Send 1 0];
bit_temp11=[Send 1 1];

  centr00=bin2decFun_kmodes(bit_temp00,k,weidu_juzhen,bianma_length);
  [cost00, cluster00]=calcu_len(centr00,data,numP);

  centr01=bin2decFun_kmodes(bit_temp01,k,weidu_juzhen,bianma_length);
  [cost01, cluster01]=calcu_len(centr01,data,numP);

  centr10=bin2decFun_kmodes(bit_temp10,k,weidu_juzhen,bianma_length);
  [cost10, cluster10]=calcu_len(centr10,data,numP);

  centr11=bin2decFun_kmodes(bit_temp11,k,weidu_juzhen,bianma_length);
  [cost11, cluster11]=calcu_len(centr11,data,numP);

    cost00temp=[cost00 cost01 cost10 cost11];
    [~,index_maxcost]=min(cost00temp);
    if index_maxcost==1
        new_poplulation_bin=bit_temp00;
        new_cost_temp=cost00;
        cluster=cluster00;
        centr=centr00;
    elseif index_maxcost==2
        new_poplulation_bin=bit_temp01;
        new_cost_temp=cost01;
        cluster=cluster01;
        centr=centr01;
    elseif index_maxcost==3
        new_poplulation_bin=bit_temp10;
        new_cost_temp=cost10;
        cluster=cluster10;
        centr=centr10;
    elseif index_maxcost==4
        new_poplulation_bin=bit_temp11;
        new_cost_temp=cost11;
        cluster=cluster11;
        centr=centr11;
    end
elseif D_mod==0
    new_poplulation_bin=Send;
    centr_temp=bin2decFun_kmodes(new_poplulation_bin,k,weidu_juzhen,bianma_length);
    [new_cost_temp, cluster]=calcu_len(centr_temp,data,numP); 
    centr=centr_temp;
end
%{
  while new_cost_temp==Dim*k
    mutatepoint=round(rand(1)*(D*Dim+D_mod));% 选择变异的位置
    % 将对应基因位置的二进制数反转
    if(mutatepoint==0)
    mutatepoint=1;
    end
    newpop_mutate=new_poplulation_bin;
    if  newpop_mutate(mutatepoint)==0
    newpop_mutate(mutatepoint)=1; %将对应基因位置的二进制数反转
    elseif newpop_mutate(mutatepoint)==1
    newpop_mutate(mutatepoint)=0;
    end
    new_poplulation_bin=newpop_mutate;
    massvaluetemp=new_poplulation_bin*mass;%%%%%%%%%%%%%%计算总质量
    if massvaluetemp<=limit0
       new_cost_temp=new_poplulation_bin*price;%%%%%%%%%%%%%%总质量低于40则适应度即价值
    else
        new_cost_temp=0;%%%%%%%%%%%%%%%%%%%%否则适应度为0
    end
  end
  %}
end
% coin1pi(:,:,pi)=coin1;
% end
