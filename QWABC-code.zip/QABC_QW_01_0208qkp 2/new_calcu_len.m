
function [min_dist,  clusters]=new_calcu_len(centroid,data)
global k 
%centr = points(:,inti_pops_temp);
%centroids = reshape(centroid, Dim, k).';
min_dist=0;
[n, m] = size(data);
        % 第一步: 根据新距离度量将每个样本分配到最近的聚类
        for i = 1:n
            distances = zeros(1, k);  % 初始化当前样本到所有聚类中心的距离
            for j = 1:k
                distances(j) = new_distance(data(i, :), centroid(j, :), data,m); % 计算到第 j 个中心的距离
            end
            [min_dist_temp, clusters(i)] = min(distances); % 找到最小距离对应的聚类
            min_dist=min_dist+min_dist_temp;
        end
end