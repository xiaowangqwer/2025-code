function [cluster,temp_centr,record2,add_Generation,accuracy] = new_QABC_kModes_data(K,data,centr,iter,datalabel)
% 生成将data聚成K类的最佳聚类  
global Dim k
% 迭代聚类 
    centroids = reshape(centr, Dim, k).';
    centroids_temp = zeros(size(centroids));
    temp_centr=[];
    num = 1;
    iterations =iter;
    while (~isequal(centroids_temp,centroids)&&num<20) 
        centroids_temp = centroids;
        [cost,cluster] = new_calcu_len(centroids,data);
        [accuracy,~]=CA(cluster',datalabel);  %计算精确度
        centroids = compueCentroids(data,cluster,K);
        temp_centr=[temp_centr centroids];
        num = num+1;
        iterations = iterations + 1;
        record(iterations,:)=[iterations,cost];
        disp(['Generation ' num2str(iterations) '   SSE= ' num2str(cost)]);
    end
record2=record;
add_Generation=iterations-iter;
end