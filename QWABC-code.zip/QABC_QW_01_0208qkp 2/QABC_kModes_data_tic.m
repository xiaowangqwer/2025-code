function [cluster,centroids,record2,add_Generation,accuracy] = QABC_kModes_data_tic(K,data,centr,iter,datalabel)
% 生成将data聚成K类的最佳聚类  
global Dim k
% 迭代聚类 
    centroids = reshape(centr, Dim, k).';
    centroids_temp = zeros(size(centroids));
    %temp_centr=[];
    num = 1;
    iterations =iter;
    %while (~isequal(centroids_temp,centroids)&&num<20) 
    while num<44  
        centroids_temp = centroids;
        [cluster,cost] = findClosest(data,centroids);
        %cluster([2:6,19:27,39:48,90:105,177:187],1)=2;
        [accuracy,conMtx]=CA(cluster',datalabel);  %计算精确度
        centroids = compueCentroids(data,cluster,K);
        %temp_centr=[temp_centr centroids];
        iterations = iterations + 1;

        %record(iterations,:)=[iterations,cost];
        %disp(['Generation ' num2str(iterations) '   SSE= ' num2str(cost)]);
        num = num+1;
record2=record;
add_Generation=iterations-iter;
    end
end