% clear all
 %clc
 function  Send=Qwalk(poplulation,best)
  global Dim D

%poplulation=[1 1 1 1 1 0 0 0 0 ];
%poplulation=[1 1 1];
% Dim=3;
% popsize=3;
popsize=D;
%tf=floor((pi/2)*sqrt(2^Dim));
tf=3;
% best.binary=[1,0,1];
%  vbest=best.binary;
%  vbest_m=best.binary'.*best.binary;
C0=zeros(Dim,Dim);
temp_S=[];
t_coin1=[];
%Spi=[];
%[pops lie]=size(poplulation);
Send=[];
Smid_temp=[];
%fais0=zeros(Dim,Dim);
for ii=1:Dim
    for jj=1:Dim
      if ii==jj
          C0(ii,jj)=2/Dim-1; 
          %fais0(ii,jj)=1/sqrt(Dim);
      else
          C0(ii,jj)=2/Dim;
      end
    end
end
%Id=eye(Dim,Dim);
fais0=(1/sqrt(Dim)).*ones(Dim,1);
%C1=-Id;
%C=C0.*(Id-vbest_m)+C1.*vbest_m;
% coin0=zeros(Dim,1);
% coin1=zeros(Dim,Dim^tf,tf);
% walk_coin0=zeros(Dim,1);
% walk_coin1=zeros(Dim,Dim);

for pi=1:popsize
    %%��ʼ̬���㣬����Ӳ�Ҳ�����λ�Ʋ���
   for i=1:Dim
    vsource(i)=poplulation((pi-1)*Dim+i);
   end
   
   for lengthi=1:Dim
      pop_xor=vsource;
      pop_xor(lengthi)=~logical(pop_xor(lengthi));
      S(lengthi,:)=pop_xor;
      coin0(lengthi)=dot(C0(lengthi,:),fais0);
      coin1(lengthi,lengthi)=coin0(lengthi);
   end

%coin_1=dot(C0,fais0); 
%��ʼ����
step=2;
while step<tf+1
   for walkci=1:Dim^(step-1)
     pop_xor=S(walkci,:);
     temp_coin1=coin1(:,walkci);
     for walkc1i=1:Dim
      walk_coin0(walkc1i)=dot(C0(walkc1i,:),temp_coin1);
      coin01(walkc1i,walkc1i)=walk_coin0(walkc1i);
      temp_pop_xor=pop_xor;
      temp_pop_xor(walkc1i)=~logical(pop_xor(walkc1i));
      temp_s(walkc1i,:)=temp_pop_xor;
     end
     
      temp_S=[temp_S;temp_s];
      t_coin1=[t_coin1 coin01];
      end
   S=temp_S;
   temp_S=[];
   coin1=t_coin1;
   t_coin1=[];
   step=step+1;
  end
 coin_000=0;coin_001=0;coin_010=0;coin_100=0;coin_110=0;coin_011=0;coin_101=0;coin_111=0;
 coincol=[0 0 0;0 0 1;0 1 0;1 0 0;1 1 0;0 1 1;1 0 1;1 1 1] ;
 %%%%% ����%%%
   for collapsei=1:Dim^(step-1)
       %coin_tol(collapsei)=dot(coin1(:,collapsei),coin1(:,collapsei)');
       %S_tol=[collapsei];
       if S(collapsei,:)==coincol(1,:)
           coin_000=coin_000+dot(coin1(:,collapsei),coin1(:,collapsei)');
       elseif S(collapsei,:)==coincol(2,:)
           coin_001=coin_001+dot(coin1(:,collapsei),coin1(:,collapsei)');
       elseif S(collapsei,:)==coincol(3,:)
           coin_010=coin_010+dot(coin1(:,collapsei),coin1(:,collapsei)');
       elseif S(collapsei,:)==coincol(4,:)
           coin_100=coin_100+dot(coin1(:,collapsei),coin1(:,collapsei)');
       elseif S(collapsei,:)==coincol(5,:)
           coin_110=coin_110+dot(coin1(:,collapsei),coin1(:,collapsei)');
       elseif S(collapsei,:)==coincol(6,:)
           coin_011=coin_011+dot(coin1(:,collapsei),coin1(:,collapsei)');
       elseif S(collapsei,:)==coincol(7,:)
           coin_101=coin_101+dot(coin1(:,collapsei),coin1(:,collapsei)');
       elseif S(collapsei,:)==coincol(8,:)
           coin_111=coin_111+dot(coin1(:,collapsei),coin1(:,collapsei)');
       end
   end
    coin_tol=[coin_000 coin_001 coin_010 coin_100 coin_110 coin_111 coin_011 coin_101];
    [coinmax,smax]=max(coin_tol);
    coin_max(pi)=coinmax;
    Spi(pi,:)=coincol(smax,:);
    %%%%%%%%%�ֱ�����%%%%%%%%%%
    Smid=poplulation;
    for i=1:Dim
        Smid((pi-1)*Dim+i)=Spi(pi,i);
    end
    Send(pi,:)=Smid;
    %%%%%%%�Աȷֱ�����%%%%%%%%%%
    
    
    
    %%%%%%%%%%%%���Ե������ߣ�ƴ��%%%%%%%
   % Send=[Send Spi(pi,:)];
%                   



%%S_tol(collapsei)=[S_tol collapsej];
%                   coin_tol(collapsei)=coin_tol(collapsei)+dot(coin1(:,collapsej),coin1(:,collapsej)');
%               end
%        for collapsej=collapsei+1:Dim^(step-1)       
%               if S(collapsej,:)==S(collapsei,:)
%                   S_tol(collapsei)=[S_tol collapsej];
%                   coin_tol(collapsei)=coin_tol(collapsei)+dot(coin1(:,collapsej),coin1(:,collapsej)');
%               end
%            end
       
 
   %%%%%%%%%%%%%%%%%%%%%%
%    for lengthi=1:Dim
%       pop_xor=vsource;
%       pop_xor(lengthi)=~logical(pop_xor(lengthi));
%       S(lengthi,:,pi)=pop_xor;
%    end
   %applyC=S.*C.*vsourcel'; 
   
end

% coin1pi(:,:,pi)=coin1;
% end
